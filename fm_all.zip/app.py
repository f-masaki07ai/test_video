# -*- coding: utf-8 -*-
"""
Created on Mon Apr 17 18:18:39 2023

@author: fujii masaki
"""
from flask import Flask, render_template,request
from youtubeapi import youtube_search
#youtubeapiを使えるようにする
app = Flask(__name__)

@app.route('/')
def index1():
    return render_template('index1.html')

@app.route('/you2')
def index2():
    videos2=youtube_search("スマホ依存")
    return render_template('index2.html')

@app.route('/you3',methods=["POST"])
def index3():
    search = request.form['search']
    videos3=youtube_search(search)
    return render_template('index3.html',videos3=videos3)

@app.route('/you4')
def index4():
    return render_template('index4.html')        

if __name__ == "__main__":
    app.run(debug=True)